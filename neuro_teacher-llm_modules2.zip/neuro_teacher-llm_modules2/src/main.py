# src/main.py
from student import Student
from grader import Grader
from llm_api import LLMAPI

def main():
    # example
    student = Student(name="Ali", course=1, discipline="Информатика", theme="Инфобезопасность")
    question = "Explain the importance of cybersecurity in modern organizations."
    student_answer = student.submit_answer("Cybersecurity is important because...")

    # grading
    grader = Grader()
    result = grader.grade_student(question, student_answer)

    # result
    print(f"Student: {student.name}")
    print(f"Course: {student.course}")
    print(f"Discipline: {student.discipline}")
    print(f"Theme: {student.theme}")
    print("Result:", result["result"])

if __name__ == "__main__":
    main()
