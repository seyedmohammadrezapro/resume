from fastapi import FastAPI
from pydantic import BaseModel

# Input data model (from student)
class StudentRequest(BaseModel):
    theme: str
    discipline: str
    course: int
    student_answer: str

# Output data model (API response)
class GradingResponse(BaseModel):
    resume_from_llm: str
    grades: int

# Create FastAPI application
app = FastAPI()

# Define a route for processing requests
@app.post("/grade", response_model=GradingResponse)
def grade_student(request: StudentRequest):
    """
    This function receives student data and assigns a grade
    """
    # Simulate grading and processing
    resume = f"Processed theme: {request.theme}, discipline: {request.discipline}, answer: {request.student_answer}"
    grade = len(request.student_answer) % 100  # Simple example: length of student's text as grade

    return GradingResponse(
        resume_from_llm=resume,
        grades=grade
    )
