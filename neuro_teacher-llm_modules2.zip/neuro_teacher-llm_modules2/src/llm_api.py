import os
from openai import OpenAI
from dotenv import load_dotenv
import time
import openai

# Load environment variables
load_dotenv()

class LLMAPI:
    def __init__(self):
        # Debug: Print environment variables
        print("Environment Variables:", os.environ)

        # Get API key from .env file
        self.api_key = os.getenv("API_SECRET_KEY")
        if not self.api_key:
            raise ValueError("API Key not found in environment variables.")
        
        # Create OpenAI client without proxy
        self.client = OpenAI(api_key=self.api_key)

    def evaluate_answer(self, question: str, student_answer: str) -> dict:
        retries = 3
        delay = 5  # initial delay in seconds

        for attempt in range(retries):
            try:
                # Send request to OpenAI API
                response = self.client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You are a grading assistant for student essays."},
                        {"role": "user", "content": f"Question: {question}\nStudent Answer: {student_answer}\nEvaluate the student's answer with a score out of 100 and explain why you gave that score."}
                    ],
                    max_tokens=500,
                    temperature=0.7
                )
                evaluation = response.choices[0].message.content
                return {"result": evaluation}
            except Exception as e:
                if "Rate limit" in str(e) and attempt < retries - 1:
                    print(f"Rate limit exceeded. Retrying in {delay} seconds...")
                    time.sleep(delay)
                    delay *= 2  # exponential backoff
                else:
                    raise ValueError(f"Error while communicating with LLM API: {str(e)}")
