from llm_api import LLMAPI

class Grader:
    def __init__(self):
        self.llm_api = LLMAPI()

    def grade_student(self, question: str, student_answer: str) -> dict:
        result = self.llm_api.evaluate_answer(question, student_answer)
        return result