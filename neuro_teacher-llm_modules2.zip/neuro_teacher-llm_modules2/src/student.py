class Student:
    def __init__(self, name: str, course: int, discipline: str, theme: str):
        self.name = name
        self.course = course
        self.discipline = discipline
        self.theme = theme

    def submit_answer(self, answer: str) -> str:
        return answer