# tests/test_llm_api.py
import pytest
from unittest.mock import MagicMock
from src.llm_api import LLMAPI

def test_call_openai():
    api = LLMAPI(api_key="dummy_key")
    api.call_openai = MagicMock(return_value={"response": "Hello!"})
    response = api.call_openai("test prompt")
    assert response["response"] == "Hello!"
