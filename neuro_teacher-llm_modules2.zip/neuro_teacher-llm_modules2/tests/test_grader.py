import unittest
from src.grader import Grader

class TestGrader(unittest.TestCase):
    def setUp(self):
        self.grader = Grader()

    def test_grade_student(self):
        question = "What is cybersecurity?"
        student_answer = "Cybersecurity involves protecting systems..."
        result = self.grader.grade_student(question, student_answer)
        self.assertIn("result", result)
        self.assertTrue(len(result["result"]) > 0)

if __name__ == "__main__":
    unittest.main()