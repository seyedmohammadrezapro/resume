# tests/test_student.py
from src.student import Student

def test_student_name():
    student = Student(name="John Doe", id=123)
    assert student.name == "John Doe"
    assert student.id == 123

def test_student_functionality():
    student = Student()
  
