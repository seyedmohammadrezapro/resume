Запустите файл src/main.py
